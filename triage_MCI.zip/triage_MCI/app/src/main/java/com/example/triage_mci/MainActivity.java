package com.example.triage_mci;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextToSpeech mTTS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = mTTS.setLanguage(Locale.getDefault());
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "Language not supported");
                    }
                } else {
                    Log.e("TTS", "Initialization failed");
                }
            }
        });

    }

        public void intent_to_Triage_START( View view)
        {
            Intent intent = new Intent(MainActivity.this, Triage_START.class);
            startActivity(intent);

        }

    public void intent_to_Triage_SALT(View view) {
        Intent intent = new Intent(MainActivity.this, triage_salt.class);
        startActivity(intent);

        // 实现文字转语音的功能
        String text = "请根据现场情况评估患者的SALT等级";
        if (mTTS != null) {
            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }
    }




}