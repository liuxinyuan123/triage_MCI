package com.example.triage_mci;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class triage_salt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triage_salt);


    }
}